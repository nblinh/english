package com.ennov.solr;

import com.ennov.solr.core.SolrHandlerCore;
import java.io.IOException;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-29
 * @project name : testPerfSolr
 * @package name : com.ennov.solr
 * @filename : .java
 */
public class TaskMod {
  public void showTaskMod() throws IOException, SolrServerException {
    System.out.println("------------------------- Gestion des tâches --------------------------");
    SolrHandlerCore solrHandlingCore = new SolrHandlerCore("", "task");

    //Show all task list
    QueryResponse queryResponse =  solrHandlingCore.retrieveAllDocuments();
    System.out.println(queryResponse.jsonStr());

  }
}
