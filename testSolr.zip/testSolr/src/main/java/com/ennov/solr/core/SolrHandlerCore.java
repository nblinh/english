package com.ennov.solr.core;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.apache.solr.client.solrj.request.QueryRequest;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-22
 * @project name : testPerfSolr
 * @package name : com.ennov.solr.core
 * @filename : .java
 */

public class SolrHandlerCore {

  private static final String hostNameDefault = "http://localhost:8983/solr";
  SolrClient solrClient;
  public static final int updateLimitSync = 1000;

  public SolrHandlerCore(String hostNameCustomize, String coreName) {
    if (hostNameCustomize.isEmpty()) {
      this.solrClient = new HttpSolrClient.Builder(hostNameDefault + "/" + coreName)
          .build();
    } else {
      this.solrClient = new HttpSolrClient.Builder(hostNameCustomize + "/" + coreName)
          .build();
    }
  }

  private SolrQuery setQuerySolr(String sQuery, int nbRows) {
    SolrQuery query = new SolrQuery();
    query.setQuery(sQuery);
    query.setRows(nbRows);

    return query;
  }

  private void solrCommit(SolrInputDocument solrInputDocument)
      throws SolrServerException, IOException {
    solrClient.add(solrInputDocument);
    solrClient.commit();
  }


  public long numRecordsFound(String sQuery, int nbRows)
      throws IOException, SolrServerException {

    SolrQuery solrQuery = this.setQuerySolr(sQuery, nbRows);
    QueryResponse queryResponse = solrClient.query(solrQuery);
    SolrDocumentList documentList = queryResponse.getResults();

    return documentList.getNumFound();
  }


  public SolrInputDocument addOrUpdateDocumentByObject(ISolrable object)
      throws SolrServerException, IOException {
    this.solrCommit(object.getDocument());

    return object.getDocument();
  }

  /*
  public SolrInputDocument addOrUpdateDocumentByData(Map<String, String> fields,
      OperationType operationType)
      throws IOException, SolrServerException {
    SolrInputDocument solrInputDocument = new SolrInputDocument();

    for (Map.Entry<String, String> entry : fields.entrySet()) {
      String key = entry.getKey();
      String value = entry.getValue();
      if (operationType.equals(OperationType.UPDATE)) {
        solrInputDocument.addField(key, Collections.singletonMap("set", value));
      } else {
        solrInputDocument.addField(key, value);
      }
    }

    this.solrCommit(solrInputDocument);
    return solrInputDocument;
  }
*/

  public long checkDataCoreImpacted(String coreName, ISolrable objectUpdated)
      throws IOException, SolrServerException {
    SolrQuery solrQuery = this.setQuerySolr(
        coreName + "_id" + ":" + objectUpdated.getDocument().getField("id").getValue(), 0);
    QueryResponse queryResponse = solrClient.query(solrQuery);

    if (queryResponse.getResults().getNumFound() > 0) {
      return queryResponse.getResults().getNumFound();
    }
    return 0;
  }



  public void deleteDocument(long IddocToDelete, boolean isDeletedAll)
      throws SolrServerException {
    try {
      if (IddocToDelete == 0 && isDeletedAll) {
        //Deleting all of documents from Solr coreName
        solrClient.deleteByQuery("*");
      } else {
        solrClient.deleteByQuery("id:" + IddocToDelete);
      }
      solrClient.commit();
      System.out.println("Document Id=" + IddocToDelete + " deleted\n");
    } catch (IOException e) {
      System.out.println("Error deleting data from Solr : " + e.getMessage());
    }
  }


  public QueryResponse retrieveDocument(String sQuery, int nbRows, String[] fieldsToShow)
      throws IOException, SolrServerException {
    SolrQuery query = this.setQuerySolr(sQuery, nbRows);

    //Adding the field to be showed in result
    if (fieldsToShow.length > 0) {
      for (String s : fieldsToShow) {
        query.addField(s);
      }
    }
    return solrClient.query(query);
  }

  public QueryResponse retrieveAllDocuments() throws IOException, SolrServerException {
    SolrQuery query = this.setQuerySolr("*:*", 100);
    return solrClient.query(query);
  }

  public QueryResponse FacetDocument(String sQuery, int nbRows, String[] fields)
      throws IOException, SolrServerException {

    SolrQuery query = this.setQuerySolr(sQuery, nbRows);

    StringBuilder fieldsList = new StringBuilder();
    if (fields.length > 0) {
      for (String field : fields) {
        query.addFacetField(field);
        fieldsList.append(field).append(" ");
      }
    }

    QueryRequest qryReq = new QueryRequest(query);

    /*
    List<FacetField> facetFields = resp.getFacetFields();
    if (facetFields.size() > 0) {
      System.out.println("Faceting query : " + sQuery + " on field(s) " + fieldsList);
      for (int i = 0; i < facetFields.size(); i++) {
        FacetField facetField = facetFields.get(i);
        List<Count> facetInfo = facetField.getValues();

        for (FacetField.Count facetInstance : facetInfo) {
          System.out.println(facetInstance.getName() + " : " +
              facetInstance.getCount());
          //+ " [drilldown qry:" +
          //facetInstance.getAsFilterQuery());
        }
      }
    }
     */

    return qryReq.process(solrClient);

  }

}