package com.ennov.solr.core;

import java.util.Collections;
import org.apache.solr.common.SolrInputDocument;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-22
 * @project name : testPerfSolr
 * @package name : com.ennov.solr.core
 * @filename : .java
 */

public class Hcp implements ISolrable {

  public long id;
  public String civility;
  public String lastname;
  public String firstname;
  public String hcpType;
  public String rppsCode;
  public String mainAddressStreet;
  public String mainAddressZipcode;
  public String mainAddressCity;
  public String mainAddressCountry;
  public String secondaryAddressStreet;
  public String secondaryAddressZipcode;
  public String secondaryAddressCity;
  public String secondaryAddressCountry;

  public final OperationType operationType;

  public String impactedCore = "contract";

  public Hcp(OperationType operationType) {
    this.operationType = operationType;
  }


  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getCivility() {
    return civility;
  }

  public void setCivility(String civility) {
    this.civility = civility;
  }

  public String getLastname() {
    return lastname;
  }

  public void setLastname(String lastname) {
    this.lastname = lastname;
  }

  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public String getHcpType() {
    return hcpType;
  }

  public void setHcpType(String hcpType) {
    this.hcpType = hcpType;
  }

  public String getRppsCode() {
    return rppsCode;
  }

  public void setRppsCode(String rppsCode) {
    this.rppsCode = rppsCode;
  }

  public String getMainAddressStreet() {
    return mainAddressStreet;
  }

  public void setMainAddressStreet(String mainAddressStreet) {
    this.mainAddressStreet = mainAddressStreet;
  }

  public String getMainAddressZipcode() {
    return mainAddressZipcode;
  }

  public void setMainAddressZipcode(String mainAddressZipcode) {
    this.mainAddressZipcode = mainAddressZipcode;
  }

  public String getMainAddressCity() {
    return mainAddressCity;
  }

  public void setMainAddressCity(String mainAddressCity) {
    this.mainAddressCity = mainAddressCity;
  }

  public String getMainAddressCountry() {
    return mainAddressCountry;
  }

  public void setMainAddressCountry(String mainAddressCountry) {
    this.mainAddressCountry = mainAddressCountry;
  }

  public String getSecondaryAddressStreet() {
    return secondaryAddressStreet;
  }

  public void setSecondaryAddressStreet(String secondaryAddressStreet) {
    this.secondaryAddressStreet = secondaryAddressStreet;
  }

  public String getSecondaryAddressZipcode() {
    return secondaryAddressZipcode;
  }

  public void setSecondaryAddressZipcode(String secondaryAddressZipcode) {
    this.secondaryAddressZipcode = secondaryAddressZipcode;
  }

  public String getSecondaryAddressCity() {
    return secondaryAddressCity;
  }

  public void setSecondaryAddressCity(String secondaryAddressCity) {
    this.secondaryAddressCity = secondaryAddressCity;
  }


  public String getSecondaryAddressCountry() {
    return secondaryAddressCountry;
  }

  public void setSecondaryAddressCountry(String secondaryAddressCountry) {
    this.secondaryAddressCountry = secondaryAddressCountry;
  }



  @Override
  public SolrInputDocument getDocument() {
    SolrInputDocument solrInputDocument = new SolrInputDocument();
    //Add new document or update document
    solrInputDocument.addField("id", this.getId());

    if (!this.getCivility().isEmpty()) {
      solrInputDocument.addField("civility",
          this.operationType == OperationType.ADD ? this.getCivility()
              : Collections.singletonMap("set", this.getCivility()));
    }

    if (!this.getLastname().isEmpty()) {
      solrInputDocument.addField("lastname",
          this.operationType == OperationType.ADD ? this.getLastname()
              : Collections.singletonMap("set", this.getLastname()));
    }
    if (!this.getFirstname().isEmpty()) {
      solrInputDocument.addField("firstname",
          this.operationType == OperationType.ADD ? this.getFirstname()
              : Collections.singletonMap("set", this.getFirstname()));
    }
    if (!this.getHcpType().isEmpty()) {
      solrInputDocument.addField("hcptype",
          this.operationType == OperationType.ADD ? this.getHcpType()
              : Collections.singletonMap("set", this.getHcpType()));
    }
    if (!this.getRppsCode().isEmpty()) {
      solrInputDocument.addField("rppscode",
          this.operationType == OperationType.ADD ? this.getRppsCode()
              : Collections.singletonMap("set", this.getRppsCode()));
    }
    if (!this.getMainAddressStreet().isEmpty()) {
      solrInputDocument.addField("mainaddress_street",
          this.operationType == OperationType.ADD ? this.getMainAddressStreet()
              : Collections.singletonMap("set", this.getMainAddressStreet()));
    }
    if (!this.getMainAddressZipcode().isEmpty()) {
      solrInputDocument.addField("mainaddress_zipcode",
          this.operationType == OperationType.ADD ? this.getMainAddressZipcode()
              : Collections.singletonMap("set", this.getMainAddressZipcode()));
    }
    if (!this.getMainAddressCity().isEmpty()) {
      solrInputDocument.addField("mainaddress_city",
          this.operationType == OperationType.ADD ? this.getMainAddressCity()
              : Collections.singletonMap("set", this.getMainAddressCity()));
    }

    if (!this.getMainAddressCountry().isEmpty()) {
      solrInputDocument.addField("mainaddress_country",
          this.operationType == OperationType.ADD ? this.getMainAddressCountry()
              : Collections.singletonMap("set", this.getMainAddressCountry()));
    }
    if (!this.getSecondaryAddressStreet().isEmpty()) {
      solrInputDocument.addField("secondaryaddress_street",
          this.operationType == OperationType.ADD ? this.getSecondaryAddressStreet()
              : Collections.singletonMap("set", this.getSecondaryAddressStreet()));
    }
    if (!this.getSecondaryAddressZipcode().isEmpty()) {
      solrInputDocument.addField("secondaryaddress_zipcode",
          this.operationType == OperationType.ADD ? this.getSecondaryAddressZipcode()
              : Collections.singletonMap("set", this.getSecondaryAddressZipcode()));
    }
    if (!this.getSecondaryAddressCity().isEmpty()) {
      solrInputDocument.addField("secondaryaddress_city",
          this.operationType == OperationType.ADD ? this.getSecondaryAddressCity()
              : Collections.singletonMap("set", this.getSecondaryAddressCity()));
    }
    if (!this.getSecondaryAddressCountry().isEmpty()) {
      solrInputDocument.addField("secondaryaddress_country",
          this.operationType == OperationType.ADD ? this.getSecondaryAddressCountry()
              : Collections.singletonMap("set", this.getSecondaryAddressCountry()));
    }

    return solrInputDocument;
  }

}
