package com.ennov.solr.core;

import java.util.Collections;
import org.apache.lucene.document.StringField;
import org.apache.solr.common.SolrInputDocument;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-22
 * @project name : testPerfSolr
 * @package name : com.ennov.solr.core
 * @filename : .java
 */

public class Contract implements ISolrable {
  private long id;
  private String contractWith;
  private String contractdescription;
  private String startDate;
  private String endDate;
  private String totalAmount;
  private String hcpId;
  private String hcpLastname;
  private String hcpFirstname;
  private String hcpRpps;
  private boolean enabled;

  public final OperationType operationType;

  public Contract(OperationType operationType) {
    this.operationType = operationType;
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getContractWith() {
    return contractWith;
  }

  public void setContractWith(String contractWith) {
    this.contractWith = contractWith;
  }


  public String getContractdescription() {
    return contractdescription;
  }

  public void setContractDescription(String contractdescription) {
    this.contractdescription = contractdescription;
  }

  public String getStartDate() {
    return startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public String getEndDate() {
    return endDate;
  }

  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

  public String getTotalAmount() {
    return totalAmount;
  }

  public void setTotalAmount(String totalAmount) {
    this.totalAmount = totalAmount;
  }

  public String getHcpId() {
    return hcpId;
  }

  public void setHcpId(String hcpId) {
    this.hcpId = hcpId;
  }

  public String getHcpLastname() {
    return hcpLastname;
  }

  public void setHcpLastname(String hcpLastname) {
    this.hcpLastname = hcpLastname;
  }

  public String getHcpFirstname() {
    return hcpFirstname;
  }

  public void setHcpFirstname(String hcpFirstname) {
    this.hcpFirstname = hcpFirstname;
  }

  public String getHcpRpps() {
    return hcpRpps;
  }

  public void setHcpRpps(String hcpRpps) {
    this.hcpRpps = hcpRpps;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  @Override
  public SolrInputDocument getDocument() {
    SolrInputDocument solrInputDocument = new SolrInputDocument();
    //Add new document or update document
    solrInputDocument.addField("id", this.getId());


    if (!this.getContractWith().isEmpty()) {
      solrInputDocument.addField("contratwith",
          this.operationType == OperationType.ADD ? this.getContractWith()
              : Collections.singletonMap("set", this.getContractWith()));
    }


    if (!this.getContractdescription().isEmpty()) {
      solrInputDocument.addField("description",
          this.operationType == OperationType.ADD ? this.getContractdescription()
              : Collections.singletonMap("set", this.getContractdescription()));
    }

    if (!this.getStartDate().isEmpty()) {
      solrInputDocument.addField("startdate",
          this.operationType == OperationType.ADD ? this.getStartDate()
              : Collections.singletonMap("set", this.getStartDate()));
    }

    if (!this.getEndDate().isEmpty()) {
      solrInputDocument.addField("enddate",
          this.operationType == OperationType.ADD ? this.getEndDate()
              : Collections.singletonMap("set", this.getEndDate()));
    }

    if (!this.getTotalAmount().isEmpty()) {
      solrInputDocument.addField("totalamount",
          this.operationType == OperationType.ADD ? this.getTotalAmount()
              : Collections.singletonMap("set", this.getTotalAmount()));
    }

    if (!this.getHcpId().isEmpty()) {
      solrInputDocument.addField("hcp_id",
          this.operationType == OperationType.ADD ? this.getHcpId()
              : Collections.singletonMap("set", this.getHcpId()));
    }

    if (!this.getHcpLastname().isEmpty()) {
      solrInputDocument.addField("hcp_lastname",
          this.operationType == OperationType.ADD ? this.getHcpLastname()
              : Collections.singletonMap("set", this.getHcpLastname()));
    }

    if (!this.getHcpFirstname().isEmpty()) {
      solrInputDocument.addField("hcp_firstname",
          this.operationType == OperationType.ADD ? this.getHcpFirstname()
              : Collections.singletonMap("set", this.getHcpFirstname()));
    }

    if (!this.getHcpRpps().isEmpty()) {
      solrInputDocument.addField("hcp_rpps",
          this.operationType == OperationType.ADD ? this.getHcpRpps()
              : Collections.singletonMap("set", this.getHcpRpps()));
    }

    if (!this.isEnabled()) {
      solrInputDocument.addField("enabled",
          this.operationType == OperationType.ADD ? this.isEnabled()
              : Collections.singletonMap("set", this.isEnabled()));
    }

    return solrInputDocument;
  }


}
