package com.ennov.solr;

import com.ennov.solr.core.Contract;
import com.ennov.solr.core.Hcp;
import com.ennov.solr.core.OperationType;
import com.ennov.solr.core.SolrHandlerCore;
import com.ennov.solr.core.TaskList;
import com.ennov.solr.utility.Utility;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-26
 * @project name : testPerfSolr
 * @package name : com.ennov.solr
 * @filename : .java
 */
public class HcpMod {

  public void showHcpMod() throws IOException, SolrServerException {
    SolrHandlerCore solrHandlerCore;
    Scanner sc = new Scanner(System.in);
    long begin;
    long current;

    System.out.println(
        "------------------------- Gestion des professionnel de santé --------------------------");
    solrHandlerCore = new SolrHandlerCore("", "hcp");
    SolrInputDocument solrInputDocument;
    QueryResponse queryResponse;

    begin = System.currentTimeMillis();
    current = begin;
    long numberRecords = solrHandlerCore.numRecordsFound("*:*", 0);
    String pattern = "###,###.###";
    DecimalFormat decimalFormat = new DecimalFormat(pattern);
    System.out.println("" + decimalFormat.format(numberRecords) + " professionels de santé in Solr ( " + (
            System.currentTimeMillis() - current)
            + " ms spent)\n");

    System.out.println("Que voulez-vous faire ?");
    System.out.println("1. Ajouter un nouveau professsionel de santé");
    System.out.println("2. Mettre à jour un professionel de santé");
    System.out.println("3. Supprimer un professionel de santé");
    System.out.println("4. Recherche des professsionel de santé par critères");
    System.out.println("5. Recherche des professsionel de santé par facette");
    System.out.println("Taper votre choix :");
    int choice = Integer.parseInt(sc.nextLine());

    Hcp hcp;
    long idDoc;

    switch (choice) {
      case 1:
        hcp = new Hcp(OperationType.ADD);
        System.out.println("Tapez le id : ");
        hcp.setId(Long.parseLong(sc.nextLine()));

        System.out.println("Tapez la civilité : ");
        hcp.setCivility(sc.nextLine());

        System.out.println("Tapez le nom : ");
        hcp.setLastname(sc.nextLine());

        System.out.println("Tapez le prénom : ");
        hcp.setFirstname(sc.nextLine());

        System.out.println("Tapez le type de professionel de santé : ");
        hcp.setHcpType(sc.nextLine());

        System.out.println("Tapez le code rpps : ");
        hcp.setRppsCode(sc.nextLine());

        System.out.println("Tapez l'adresse pricipale : ");
        hcp.setMainAddressStreet(sc.nextLine());

        System.out.println("Tapez le code postal (adresse pricipale) : ");
        hcp.setMainAddressZipcode(sc.nextLine());

        System.out.println("Tapez la ville (adresse pricipale) : ");
        hcp.setMainAddressCity(sc.nextLine());

        System.out.println("Tapez le pays (adresse pricipale) : ");
        hcp.setMainAddressCountry(sc.nextLine());

        System.out.println("Tapez l'adresse secondaire : ");
        hcp.setSecondaryAddressStreet(sc.nextLine());

        System.out.println("Tapez le code postal (adresse secondaire) : ");
        hcp.setSecondaryAddressZipcode(sc.nextLine());

        System.out.println("Tapez la ville (adresse secondaire) : ");
        hcp.setSecondaryAddressCity(sc.nextLine());

        System.out.println("Tapez le pays (adresse secondaire) : ");
        hcp.setSecondaryAddressCountry(sc.nextLine());

        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        solrInputDocument = solrHandlerCore.addOrUpdateDocumentByObject(hcp);
        System.out.println("Document : "+ solrInputDocument.getField("id") + " a été crée avec succès");
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");

        break;
      case 2:
        hcp = new Hcp(OperationType.UPDATE);
        System.out.println(
            "Attention : La mise à jour ne sera pas prise en compte si vous laissez le champ vide !!!");
        System.out.println("Tapez le id du document pour le mettre à jour ");
        hcp.setId(Long.parseLong(sc.nextLine()));

        System.out.println("Tapez la nouvelle valeur de la civilité : ");
        hcp.setCivility(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du nom : ");
        hcp.setLastname(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du prénom : ");
        hcp.setFirstname(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du type professionel de santé : ");
        hcp.setHcpType(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du code rpps : ");
        hcp.setRppsCode(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur de l'adresse pricipale : ");
        hcp.setMainAddressStreet(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du code postal (adresse pricipale) : ");
        hcp.setMainAddressZipcode(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur de la ville (adresse pricipale) : ");
        hcp.setMainAddressCity(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du pays (adresse pricipale) : ");
        hcp.setMainAddressCountry(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur de l'adresse secondaire : ");
        hcp.setSecondaryAddressStreet(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du code postal (adresse secondaire) : ");
        hcp.setSecondaryAddressZipcode(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur de la ville (adresse secondaire) : ");
        hcp.setSecondaryAddressCity(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du pays (adresse secondaire) : ");
        hcp.setSecondaryAddressCountry(sc.nextLine());

        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        SolrInputDocument solrInputDocumentHcp = solrHandlerCore.addOrUpdateDocumentByObject(hcp);
        System.out.println("Document : "+ solrInputDocumentHcp.jsonStr() + " a été mise à jour avec succès");
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");

        //check of documents impacted
        System.out.println("Vérifier les documents impactés...");
        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        solrHandlerCore = new SolrHandlerCore("", hcp.impactedCore);
        long numberDocumentsImpacted = solrHandlerCore.checkDataCoreImpacted("hcp", hcp);
        System.out.println(numberDocumentsImpacted + " document(s) du " + hcp.impactedCore + " core trouvés");
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");

        //Add to task list
        System.out.println("Ajouter une tâche pour la mise à jour des documents impactés...");
        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;

        if (numberDocumentsImpacted > 0) {
          solrHandlerCore = new SolrHandlerCore("", "task");
          TaskList taskList = new TaskList(OperationType.ADD);
          taskList.setId(Utility.createUniqueKey());
          taskList.setCreationDate(Utility.getCurrentDateTime());
          taskList.setLastModificationDate(Utility.getCurrentDateTime());
          taskList.setIdItem((Long) hcp.getDocument().getField("id").getValue());
          taskList.setCoreName("hcp");
          taskList.setFieldsUpdated(hcp.getDocument().jsonStr());
          taskList.setCoresImpacted(hcp.impactedCore);
          taskList.setNumDocImpacted(numberDocumentsImpacted);
          taskList.setStatus("Done");
          solrHandlerCore.addOrUpdateDocumentByObject(taskList);
          System.out.println("Tâche Id = "+taskList.getId()+" a été créee avec succès...");

        }
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");
        if(numberDocumentsImpacted <= solrHandlerCore.updateLimitSync) {

          System.out.println("Le nombre de dossiers impactés "+ numberDocumentsImpacted + " < "+solrHandlerCore.updateLimitSync+"\n");
          System.out.println("La mise à jour des documents impactés commence...");
          System.out.println("\nBegin of treatment...\n");
          begin = System.currentTimeMillis();
          current = begin;

          solrHandlerCore = new SolrHandlerCore("", "contract");
          String[] fieldsToShowUpdate = {"id", "hcp_id", "hcp_lastname", "hcp_firstname",
              "hcp_rpps"};
          queryResponse = solrHandlerCore.retrieveDocument("hcp_id:" + hcp.getId(), 100, fieldsToShowUpdate);
          SolrDocumentList documentList = queryResponse.getResults();
          Contract contract;
          for (int i = 0; i < documentList.size(); i++) {
            contract = new Contract(OperationType.UPDATE);
            contract.setId(Long.parseLong(documentList.get(i).getFieldValue("id").toString()));
            contract.setContractWith("");
            contract.setContractDescription("");
            contract.setStartDate("");
            contract.setEndDate("");
            contract.setTotalAmount("");
            contract.setHcpId("");
            contract.setHcpLastname(hcp.getLastname());
            contract.setHcpFirstname(hcp.getFirstname());
            contract.setHcpRpps(hcp.getRppsCode());
            contract.setEnabled(true);
            solrHandlerCore.addOrUpdateDocumentByObject(contract);
            System.out.println(
                "La mise à jour du contrat id = " + contract.getId() + " effectuée avec succès");
          }
          System.out.println(
              "\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");
        }
        //306891682757116

        break;
      case 3:
        System.out.println("Tapez le id du document à supprimer");
        idDoc = sc.nextLong();
        System.out.println("\nBegin of treatment...\n");
        sc.nextLine();
        begin = System.currentTimeMillis();
        current = begin;
        solrHandlerCore.deleteDocument(idDoc, false);
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");
        break;
      case 4:
        System.out.println("les champs de recherche diponibles : "
            + "civility, "
            + "lastname, "
            + "firstname, "
            + "hcptype (Medecin, Pharmacien, Infirmier, Sage-femme, Ambulancier...), "
            + "rppscode, "
            + "mainaddress_street, "
            + "mainaddress_zipcode, "
            + "mainaddress_city, "
            + "mainaddress_country. "
            + "(Exemple de recherche : lastname:NGUYEN AND firstname:Lionel AND....)");

        System.out.println("Veuillez saisir les critère de recherche !");
        String query = sc.nextLine();

        System.out.println("Veuillez saisir le nombre de résultats maximum affichés à l'écran !");
        int nbRows = Integer.parseInt(sc.nextLine());

        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        String[] fieldsToShow = {};
        queryResponse = solrHandlerCore.retrieveDocument(query, nbRows, fieldsToShow);
        System.out.println(queryResponse.jsonStr());
        System.out.println("Nombre de documents trouvés: " + queryResponse.getResults().getNumFound());
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");
        break;
      case 5:
        System.out.println("les champs de recherche diponibles : "
            + "civility, "
            + "lastname, "
            + "firstname, "
            + "hcptype (Medecin, Pharmacien, Infirmier, Sage-femme, Ambulancier...), "
            + "mainaddress_street, "
            + "mainaddress_zipcode, "
            + "mainaddress_city, "
            + "mainaddress_country. "
            + "(Exemple de recherche : lastname:NGUYEN AND firstname:Lionel AND....)");

        System.out.println("Veuillez saisir les critère de recherche !");
        String queryFacet = sc.nextLine();

        System.out.println("Veuillez saisir les critère de facette !");
        String fieldsToFacet = sc.nextLine();

        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        String[] fieldsToShowFacet = {fieldsToFacet};
        queryResponse = solrHandlerCore.FacetDocument(queryFacet, 0, fieldsToShowFacet);
        System.out.println(queryResponse.jsonStr());
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");

        break;
      default:
        System.out.println("Veuillez respecter le menu!");
    }
  }
}


