package com.ennov.solr;

import com.ennov.solr.core.Contract;
import com.ennov.solr.core.OperationType;
import com.ennov.solr.core.SolrHandlerCore;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrInputDocument;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-26
 * @project name : testPerfSolr
 * @package name : com.ennov.solr
 * @filename : .java
 */
public class ContratMod {
  public void showContractMod () throws IOException, SolrServerException {
    SolrHandlerCore solrHandlingCore = new SolrHandlerCore("", "contract");
    Scanner sc = new Scanner(System.in);
    long begin;
    long current;

    System.out.println(
        "------------------------- Gestion des contrats --------------------------");
    SolrInputDocument solrInputDocument;
    QueryResponse queryResponse;

    begin = System.currentTimeMillis();
    current = begin;
    String pattern = "###,###.###";
    DecimalFormat decimalFormat = new DecimalFormat(pattern);
    long numberRecords = solrHandlingCore.numRecordsFound("*:*", 0);
    System.out.println(
        "" + decimalFormat.format(numberRecords)  + " contrats in Solr ( " + (System.currentTimeMillis() - current)
            + " ms spent)\n");

    System.out.println("Que voulez-vous faire");
    System.out.println("1. Ajouter un nouveau contrat");
    System.out.println("2. Mettre à jour un contrat");
    System.out.println("3. Supprimer un contrat");
    System.out.println("4. Recherche par critères");
    System.out.println("5. Recherche par facet");
    System.out.println("Taper votre choix :");
    int choice = Integer.parseInt(sc.nextLine());

    Contract contract;
    long idDoc;

    switch (choice) {
      case 1:
        contract = new Contract(OperationType.ADD);

        System.out.println("Tapez le contract Id: ");
        contract.setId(Long.parseLong(sc.nextLine()));

        System.out.println("Tapez le contrat avec (ex: Medecin, Pharmacien, Infirmier...): ");
        contract.setContractWith(sc.nextLine());

        System.out.println("Tapez les descriptions du contrat : ");
        contract.setContractDescription(sc.nextLine());

        System.out.println("Tapez la date de début du contrat : ");
        contract.setStartDate(sc.nextLine());

        System.out.println("Tapez la date de fin du contrat : ");
        contract.setEndDate(sc.nextLine());

        System.out.println("Tapez le montant total du contrat : ");
        contract.setTotalAmount(sc.nextLine());

        System.out.println("Tapez le professionel de santé ID du contrat : ");
        contract.setHcpId(sc.nextLine());

        System.out.println("Tapez le nom du professionel de santé : ");
        contract.setHcpLastname(sc.nextLine());

        System.out.println("Tapez le prénom du professionel de santé : ");
        contract.setHcpFirstname(sc.nextLine());

        System.out.println("Tapez le code RPPS du professionel de santé : ");
        contract.setHcpRpps(sc.nextLine());

        System.out.println("Tapez le statut du contrat : ");
        contract.setEnabled(Boolean.parseBoolean(sc.nextLine()));

        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        solrInputDocument = solrHandlingCore.addOrUpdateDocumentByObject(contract);
        System.out.println("Document : "+ solrInputDocument.getField("id") + " a été crée avec succès");
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");

        break;
      case 2:
        contract = new Contract(OperationType.UPDATE);
        System.out.println(
            "Attention : La mise à jour d'un champ ne sera pas prise en compte si vous laissez ce champ vide !!!");

        System.out.println("Tapez le id du document pour le mettre à jour ");
        contract.setId(Long.parseLong(sc.nextLine()));

        System.out.println("Tapez la nouvelle valeur du 'contrat avec' (ex: personne physique, personne morale): ");
        contract.setContractWith(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur des descriptions : ");
        contract.setContractDescription(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur de la date de début : ");
        contract.setStartDate(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur de la date de fin : ");
        contract.setEndDate(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du montant total : ");
        contract.setTotalAmount(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur de l'ID professionel de santé : ");
        contract.setHcpId(sc.nextLine());

        System.out.println("Tapez a nouvelle valeur du nom du professionel de santé : ");
        contract.setHcpLastname(sc.nextLine());

        System.out.println("Tapez a nouvelle valeur du prénom du professionel de santé : ");
        contract.setHcpFirstname(sc.nextLine());

        System.out.println("Tapez a nouvelle valeur du le code RPPS du professionel de santé : ");
        contract.setHcpRpps(sc.nextLine());

        System.out.println("Tapez la nouvelle valeur du statut du contrat : ");
        contract.setEnabled(Boolean.parseBoolean(sc.nextLine()));

        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        solrInputDocument = solrHandlingCore.addOrUpdateDocumentByObject(contract);
        System.out.println("Document : "+ solrInputDocument.getField("id") + " a été crée avec succès");
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");
        break;

      case 3:
        System.out.println("Tapez le id du document à supprimer");
        idDoc = sc.nextLong();
        sc.nextLine();

        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        solrHandlingCore.deleteDocument(idDoc, false);
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");
        break;
      case 4:
        System.out.println("les champs de recherche diponibles : "
            + "contratwith, "
            + "title, "
            + "description, "
            + "startdate (ex:2019-03-17), "
            + "enddate (ex:2019-03-17), "
            + "totalamount, "
            + "hcp_id"
            + "(Exemple de recherche : contratwith:Medecin AND startdate:2019-03-17 AND....)");

        System.out.println("Veuillez saisir les critère de recherche !");
        String query = sc.nextLine();

        System.out.println("Veuillez saisir le nombre de résultats maximum affichés à l'écran !");
        int nbRows = Integer.parseInt(sc.nextLine());

        System.out.println("\nBegin of treatment...\n");
        begin = System.currentTimeMillis();
        current = begin;
        String[] fieldsToShow = {};
        queryResponse = solrHandlingCore.retrieveDocument(query, nbRows, fieldsToShow);
        System.out.println(queryResponse.jsonStr());
        System.out.println("Nombre de documents trouvés: " + queryResponse.getResults().getNumFound());
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");

        break;
      case 5:
        System.out.println("les champs de recherche diponibles : "
            + "contratwith, "
            + "description, "
            + "startdate (ex:2019-03-17), "
            + "enddate (ex:2019-03-17), "
            + "totalamount, "
            + "(Exemple de recherche : contratwith:Medecin AND startdate:2019-03-17 AND....)");

        System.out.println("Veuillez saisir les critère de facette !");
        String queryFacet = sc.nextLine();

        System.out.println("Veuillez saisir les critère de facette !");
        String fieldsToFacet = sc.nextLine();

        begin = System.currentTimeMillis();
        current = begin;
        String[] fieldsToShowFacet = {fieldsToFacet};
        queryResponse = solrHandlingCore.FacetDocument(queryFacet, 0, fieldsToShowFacet);
        System.out.println(queryResponse.jsonStr());
        System.out.println("\nEnd of treatment : " + (System.currentTimeMillis() - current) + " ms spent\n");
        break;
      default:
        System.out.println("Veuillez respecter le menu!");
    }

  }
}
