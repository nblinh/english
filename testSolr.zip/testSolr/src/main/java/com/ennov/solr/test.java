package com.ennov.solr;

import java.util.UUID;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-29
 * @project name : testPerfSolr
 * @package name : com.ennov.solr
 * @filename : .java
 */
public class test {

  public static void main(String[] args) {
    UUID uniqueKey = UUID.randomUUID();
    System.out.println (uniqueKey.toString());
  }

}
