package com.ennov.solr.core;

import java.util.Collections;
import org.apache.solr.common.SolrInputDocument;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-28
 * @project name : testPerfSolr
 * @package name : com.ennov.solr.core
 * @filename : .java
 */
public class TaskList implements ISolrable{
  private String creationDate;
  private String lastModificationDate;
  private String id;
  private long idItem; //item id updated unique key
  private String coreName;
  private String fieldsUpdated;
  private String coresImpacted;
  private long numDocImpacted;
  private String status;

  public final OperationType operationType;

  public TaskList(OperationType operationType) {
    this.operationType = operationType;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public long getIdItem() {
    return idItem;
  }

  public void setIdItem(long idItem) {
    this.idItem = idItem;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public String getLastModificationDate() {
    return lastModificationDate;
  }

  public void setLastModificationDate(String lastModificationDate) {
    this.lastModificationDate = lastModificationDate;
  }

  public String getCoreName() {
    return coreName;
  }

  public void setCoreName(String coreName) {
    this.coreName = coreName;
  }

  public String getCoresImpacted() {
    return coresImpacted;
  }

  public void setCoresImpacted(String coresImpacted) {
    this.coresImpacted = coresImpacted;
  }

  public String getFieldsUpdated() {
    return fieldsUpdated;
  }

  public void setFieldsUpdated(String fieldsUpdated) {
    this.fieldsUpdated = fieldsUpdated;
  }

  public long getNumDocImpacted() {
    return numDocImpacted;
  }

  public void setNumDocImpacted(long numDocImpacted) {
    this.numDocImpacted = numDocImpacted;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  @Override
  public SolrInputDocument getDocument() {
    SolrInputDocument solrInputDocument = new SolrInputDocument();

    solrInputDocument.addField("id", this.id);

    if (this.getCreationDate() != null) {
      solrInputDocument.addField("creationdate",
          this.operationType == OperationType.ADD ? this.getCreationDate()
              : Collections.singletonMap("set", this.getCreationDate()));
    }

    if (this.getLastModificationDate() != null) {
      solrInputDocument.addField("lastmodificationdate",
          this.operationType == OperationType.ADD ? this.getLastModificationDate()
              : Collections.singletonMap("set", this.getLastModificationDate()));
    }

    if (this.getIdItem()!=0) {
      solrInputDocument.addField("iditem",
          this.operationType == OperationType.ADD ? this.getIdItem()
              : Collections.singletonMap("set", this.getIdItem()));
    }

    if (!this.getCoreName().isEmpty()) {
      solrInputDocument.addField("corename",
          this.operationType == OperationType.ADD ? this.getCoreName()
              : Collections.singletonMap("set", this.getCoreName()));
    }

    if (!this.getFieldsUpdated().isEmpty()) {
      solrInputDocument.addField("fieldsupdated",
          this.operationType == OperationType.ADD ? this.getFieldsUpdated()
              : Collections.singletonMap("set", this.getFieldsUpdated()));
    }

    if (!this.getCoresImpacted().isEmpty()) {
      solrInputDocument.addField("impactcorename",
          this.operationType == OperationType.ADD ? this.getCoresImpacted()
              : Collections.singletonMap("set", this.getCoresImpacted()));
    }

    if (this.getNumDocImpacted()!=0) {
      solrInputDocument.addField("numberdocumentimpacted",
          this.operationType == OperationType.ADD ? this.getNumDocImpacted()
              : Collections.singletonMap("set", this.getNumDocImpacted()));
    }

    if (!this.getStatus().isEmpty()) {
      solrInputDocument.addField("taskstatus",
          (this.operationType == OperationType.ADD) ? this.getStatus()
              : Collections.singletonMap("set", this.getStatus()));
    }
    return solrInputDocument;
  }
}
