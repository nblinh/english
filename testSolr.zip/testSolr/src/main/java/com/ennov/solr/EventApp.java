package com.ennov.solr;

import java.io.IOException;
import java.util.Scanner;
import org.apache.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.apache.solr.client.solrj.SolrServerException;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-22
 * @project name : testPerfSolr
 * @package name : com.ennov.solr.app
 * @filename : .java
 */

public class EventApp {

  public static void main(String[] args) throws IOException, SolrServerException {

    System.setProperty("log4j2.xml","/Users/h.nguyen/ennov/event/testSolr/src/main/resources/log4j2.xml");

    Scanner sc = new Scanner(System.in);
    int choice;
    boolean startAgain = true;
    while (startAgain) {
      System.out
          .println("------------------------- Veuillez faire un choix --------------------------");
      System.out.println("1. Gestion des professionnels de santé");
      System.out.println("2. Gestion des contrats");
      System.out.println("3. Gestion des tâches");
      System.out.println("Taper votre choix :");
      choice = Integer.parseInt(sc.nextLine());

      switch (choice) {
        case 1:
          HcpMod hcpMod = new HcpMod();
          hcpMod.showHcpMod();
          break;
        case 2:
          ContratMod contratMod = new ContratMod();
          contratMod.showContractMod();
          break;
        case 3:
          TaskMod taskMod = new TaskMod();
          taskMod.showTaskMod();
          break;
        default:
          System.out.println("Veuillez respecter le menu!");
      }

      System.out.println("\nTaper 'oui' pour retouner au menu principale ? ou 'non' pour quitter");
      startAgain = sc.nextLine().equalsIgnoreCase("oui");
      if (!startAgain) {
        System.out.println("Aurevoir !!!");
      }
    }
  }
}
