package com.ennov.solr.core;

import org.apache.solr.common.SolrInputDocument;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-24
 * @project name : testPerfSolr
 * @package name : com.ennov.solr.core
 * @filename : .java
 */

public interface ISolrable {
  SolrInputDocument getDocument();
}
