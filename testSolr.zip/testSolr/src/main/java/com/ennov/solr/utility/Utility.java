package com.ennov.solr.utility;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-28
 * @project name : testPerfSolr
 * @package name : com.ennov.solr.utility
 * @filename : .java
 */
public class Utility {

  public static String getCurrentDateTime () {
    java.time.LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    LocalDateTime today = LocalDateTime.now();
    return formatter.format(today);
  }

  public static  String createUniqueKey (){
    UUID uniqueKey = UUID.randomUUID();
    return uniqueKey.toString();
  }
}
