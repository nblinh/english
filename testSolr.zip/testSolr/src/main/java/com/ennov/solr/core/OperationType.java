package com.ennov.solr.core;

import org.apache.solr.metrics.AggregateMetric.Update;

/**
 * @author : h.nguyen
 * @Creation date : 2020-04-27
 * @project name : testPerfSolr
 * @package name : com.ennov.solr.core
 * @filename : .java
 */
public enum OperationType {
  UPDATE("Update"),
  ADD ("Add");

  public String name;

  OperationType(String name) {
    this.name = name;
  }
}
